# 導入した時に出てくるメッセージ

tellraw @a ["",{"text":"Lost_Ozone_Layer","color":"green"},{"text":"\u306e\u5c0e\u5165\u306b\u6210\u529f\u3057\u307e\u3057\u305f\u3002","color":"yellow"}]

gamerule randomTickSpeed 1