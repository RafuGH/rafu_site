# 紫外線を受けた時のかかるデバフ

effect give @s minecraft:poison 1 255 true

effect give @s minecraft:wither 1 255 true
