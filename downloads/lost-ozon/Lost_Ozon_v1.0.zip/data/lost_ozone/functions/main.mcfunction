execute as @e at @s if blocks ~ ~1 ~ ~ 319 ~ ~ ~ ~ masked run function lost_ozone:lost_ozone_poison

