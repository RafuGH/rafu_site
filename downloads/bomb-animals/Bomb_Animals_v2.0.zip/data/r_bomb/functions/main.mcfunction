# カウントダウンスコア
scoreboard players add @e[tag=r_bombanimals] r_bombanimals 1

# 爆散する瞬間に透明化
effect give @e[scores={r_bombanimals=599..}] minecraft:invisibility 1 0 true

# 爆散
execute as @e[tag=r_bombanimals,scores={r_bombanimals=600..}] at @s run summon minecraft:creeper ~ ~ ~ {Fuse:0}

# 動物を爆発させるタグ付けるやつ

# 牛
tag @e[type=minecraft:cow] add r_bombanimals
# 豚
tag @e[type=minecraft:pig] add r_bombanimals
# 羊
tag @e[type=minecraft:sheep] add r_bombanimals
# 鶏
tag @e[type=minecraft:chicken] add r_bombanimals
# 兎
tag @e[type=minecraft:rabbit] add r_bombanimals
# 馬
tag @e[type=minecraft:horse] add r_bombanimals
# 驢馬
tag @e[type=minecraft:donkey] add r_bombanimals
# 蜂
tag @e[type=minecraft:bee] add r_bombanimals
# ラマ
tag @e[type=minecraft:llama] add r_bombanimals
# 狼
tag @e[type=minecraft:wolf] add r_bombanimals
# 狐
tag @e[type=minecraft:fox] add r_bombanimals
# シロクマ
tag @e[type=minecraft:polar_bear] add r_bombanimals
# ムーシュルーム
tag @e[type=minecraft:mooshroom] add r_bombanimals
# ヤマネコ
tag @e[type=minecraft:ocelot] add r_bombanimals
# オウム
tag @e[type=minecraft:parrot] add r_bombanimals
# パンダ
tag @e[type=minecraft:panda] add r_bombanimals
# イカ
tag @e[type=minecraft:squid] add r_bombanimals
# 亀
tag @e[type=minecraft:turtle] add r_bombanimals
# イルカ
tag @e[type=minecraft:dolphin] add r_bombanimals
# タラ
tag @e[type=minecraft:cod] add r_bombanimals
# サケ
tag @e[type=minecraft:salmon] add r_bombanimals
# 熱帯魚
tag @e[type=minecraft:tropical_fish] add r_bombanimals
# フグ
tag @e[type=minecraft:pufferfish] add r_bombanimals
# ストライダー
tag @e[type=minecraft:strider] add r_bombanimals
# 蝙蝠
tag @e[type=minecraft:bat] add r_bombanimals
# 猫
tag @e[type=minecraft:cat] add r_bombanimals
# 騾馬
tag @e[type=minecraft:mule] add r_bombanimals
# スケルトンホース
tag @e[type=minecraft:skeleton_horse] add r_bombanimals
# ゾンビホース
tag @e[type=minecraft:zombie_horse] add r_bombanimals
# ホグリン
tag @e[type=minecraft:hoglin] add r_bombanimals
# ウーパールーパー
tag @e[type=minecraft:axolotl] add r_bombanimals
# ヤギ
tag @e[type=minecraft:goat] add r_bombanimals
# ヒカリイカ
tag @e[type=minecraft:glow_squid] add r_bombanimals
