# 導入した時になる奴全部

# ロードしたときに表示する文字とか説明のやつ
tellraw @a ["",{"text":"--------------------------------------------------\n\n"},{"text":"[Bomb_Animals_v2.0] ","color":"green"},{"text":"\u306e\u5c0e\u5165\u306b\u6210\u529f\u3057\u307e\u3057\u305f\u3002","bold":true,"color":"green"},{"text":"\n"},{"text":"\u304a\u3044\uff01\u305d\u3053\u306e\u304a\u524d\uff01\u9042\u306b\u30dc\u30e0\u30a2\u30cb\u30de\u30eb\u30ba\u304c\u30ea\u30e1\u30a4\u30af\u7248\u3067\u5e30\u3063\u3066\u304d\u305f\u305e\uff01\n\u524d\u56de\u306b\u5f15\u304d\u7d9a\u304d\u7206\u6563\u3059\u308b\u77ac\u9593\u306b\u4e00\u5339\u305a\u3064\u8a31\u53ef\u3092\u3082\u3089\u3063\u3066\u308b\u304b\u3089\u306a\uff01","bold":true,"color":"gold"},{"text":"\n\n--------------------------------------------------"}]
schedule function r_bomb:r_load 1t append

scoreboard objectives add r_bombanimals dummy
