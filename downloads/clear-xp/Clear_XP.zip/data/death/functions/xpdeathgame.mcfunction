execute as @a at @s run playsound minecraft:block.end_portal.spawn master @a ~ ~ ~
tellraw @a ["",{"text":"\u30c7\u30b9\u30b2\u30fc\u30e0\u304c\u958b\u59cb\u3055\u308c\u307e\u3057\u305f\u3002","bold":true,"color":"dark_red"},{"text":"\n"},{"text":"\u5468\u308a\u3092\u8b66\u6212\u3057\u3088\u3046\u3002","color":"gold"},{"text":"\n"},{"text":"XP","bold":true,"color":"green"},{"text":"\u9054\u304c\u3042\u306a\u305f\u3092\u72d9\u3063\u3066\u3044\u308b\u304b\u3082\u3057\u308c\u306a\u3044...","color":"gold"}]
title @a title {"text":"\u30c7\u30b9\u30b2\u30fc\u30e0\u30e2\u30fc\u30c9","bold":true,"color":"dark_red"}
give @a minecraft:experience_bottle 3
tag @a add death_xp
tellraw @a "今から30秒の間にXPを取ってしまうとkillされてしまいます。やべえ！！！"
schedule function death:xpdeathgameend 30s replace