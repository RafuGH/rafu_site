kill @a[tag=death_xp,level=1..10]
clear @a[level=1..10]
xp set @a 0 levels
xp set @a 6 points