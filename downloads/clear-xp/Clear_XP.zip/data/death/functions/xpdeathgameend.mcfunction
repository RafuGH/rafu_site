title @a title {"text":"\u7d42\u4e86","bold":true,"color":"dark_red"}
tellraw @a {"text":"\u5831\u916c\u3068\u304b\u306f\u7279\u306b\u306a\u3044\u3088\u3002\u3054\u3081\u3093\u306d","color":"gold"}
clear @a minecraft:experience_bottle 3
tag @a remove death_xp
execute as @a at @s run playsound minecraft:entity.arrow.hit_player master @a ~ ~ ~